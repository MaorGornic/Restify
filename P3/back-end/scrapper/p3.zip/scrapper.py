from restaurant_scrapper import scrape_restaurants
from os import listdir
from os.path import isfile, join
import random
import requests


def main():
    restaurants = scrape_restaurants()

    for i in range(len(restaurants)):
    # for i in range(1):
        URL = "http://127.0.0.1:8000/accounts/register/"
        username = f"naruto{i}"
        password = "Cp98WbZYVmJM7Cj"
        email = f"naruto{i}.uzumaki@gmail.com"
        first_name = f"Naruto{i}"
        last_name = f"Uzumaki{i}"

        PARAMS = {
            "username": username,
            "password": password,
            "password2": password,
            "email": email,
            "first_name": first_name,
            "last_name": last_name
        }

        # sending get request and saving the response as response object
        r = requests.post(url=URL, data=PARAMS)
        # if r.status_code != 201:
        #     continue

        # logging in
        URL = "http://127.0.0.1:8000/accounts/api/token/"
        PARAMS = {
            "username": username,
            "password": password
        }
        r = requests.post(url=URL, data=PARAMS)

        # extracting data in json format
        data = r.json()
        token = data['access']
        # print(token)

        # create restaurant
        URL = "http://127.0.0.1:8000/restaurants/new/"
        # restaurant_data = restaurants[i]
        logo = {'logo': open(f'images/{pick_random_image()}', 'rb')}
        # print(restaurant_data)
        r = requests.post(url=URL, data=restaurants[i], files=logo, headers={'Authorization': f'Bearer {token}'})

        print(r.json())


def pick_random_image():
    images = [f for f in listdir("images") if isfile(join("images", f))]
    return random.choice(images)


if __name__ == '__main__':
    main()
